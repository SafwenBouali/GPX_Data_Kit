<h1>GPX For Strava</h1>
<hr>
<h5>Introduction</h5>
<p>GPX Strava is a python package that handles localisation data saved under the XML schema "GPS Exchange Format" (GPX). These operations are useful for extracting and handling the point recorded by your GPS device and saving them in different ways.</p>